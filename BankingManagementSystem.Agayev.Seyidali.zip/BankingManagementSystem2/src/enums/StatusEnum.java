package enums;

public enum StatusEnum {
    REGISTER_SUCCESSFULLY,
    LOG_IN_SUCCESSFULLY,
    UPDATE_SUCCESSFULLY,
    SUCCESS,
}
