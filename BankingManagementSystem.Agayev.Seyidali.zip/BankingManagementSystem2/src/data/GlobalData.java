package data;

import model.Card;
import model.Customer;

public class GlobalData {
    public static Customer[] customers;
    public static Card[] cards;
}
