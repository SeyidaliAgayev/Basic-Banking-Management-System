package service;

public interface CustomerManagementService {
    void customerManagement();
}
