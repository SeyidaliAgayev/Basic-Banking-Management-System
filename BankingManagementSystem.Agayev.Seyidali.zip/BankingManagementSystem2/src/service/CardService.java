package service;

public interface CardService {
    void showBalance();
    void cashingOut();
}
