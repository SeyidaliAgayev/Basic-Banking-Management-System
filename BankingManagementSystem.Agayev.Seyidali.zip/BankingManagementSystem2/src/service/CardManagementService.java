package service;

public interface CardManagementService {
    void cardManagement();
}
