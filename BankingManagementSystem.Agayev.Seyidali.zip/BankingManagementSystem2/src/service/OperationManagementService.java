package service;

public interface OperationManagementService {
    void operationManagement();
}
