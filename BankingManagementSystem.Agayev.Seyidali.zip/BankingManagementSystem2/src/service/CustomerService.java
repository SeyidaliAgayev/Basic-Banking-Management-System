package service;

public interface CustomerService {
    boolean register();
    void showMyDetails();
    void updateMyDetails();
    void logIn();
    void increaseBalance();
}
